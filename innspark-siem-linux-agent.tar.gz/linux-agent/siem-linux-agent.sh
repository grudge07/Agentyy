#!/bin/bash

# Create directories and move files
sudo mkdir -p /etc/siem/agent/
sudo mkdir -p /usr/bin/siem 
sudo cp SiemLinuxAgent /usr/bin/siem
sudo cp siem-agent.service /etc/systemd/system/.
sudo cp ignore_list /etc/siem/agent/. -r
sudo touch /etc/siem/agent/agent.conf

# Function to validate IP address format
validate_ip() {
    if echo "$1" | grep -Eq '^([0-9]{1,3}\.){3}[0-9]{1,3}$'; then
        return 0  # Valid IPv4 address format
    elif echo "$1" | grep -Eq '^([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$'; then
        return 0  # Valid IPv6 address format
    else
        return 1  # Invalid IP address format
    fi
}

# Function to display whiptail input box and get input
input_dialog() {
    local input_var
    local prompt="$1"
    local default="$2"

    input_var=$(whiptail --inputbox "$prompt" 10 60 "$default" --nocancel 3>&1 1>&2 2>&3)
    echo "$input_var"
}

# Function to display whiptail yes/no box for default hostname
yesno_dialog() {
    local prompt="$1"
    whiptail --yesno "$prompt" 10 60 --nocancel
}

# Function to display whiptail radiolist box for boolean input
boolean_dialog() {
    local prompt="$1"
    local default="$2"
    local input_var=$(whiptail --radiolist "$prompt" 12 60 2 \
        true "Enable" $( [ "$default" == "true" ] && echo "ON" || echo "OFF" ) \
        false "Disable" $( [ "$default" == "false" ] && echo "ON" || echo "OFF" ) --nocancel 3>&1 1>&2 2>&3)
    echo "$input_var"
}

# Loop to allow user to review and confirm configuration
continue="Y"
while [ "$continue" == "Y" ] || [ "$continue" == "y" ]; do
    # Display UI and gather inputs
    yesno_dialog "Do you want to use your default hostname ($(hostname))?"
    if [ $? -eq 0 ]; then
        hostname=$(hostname)
    else
        hostname=$(input_dialog "Enter the hostname you want (This is the hostname of the system):" "")
    fi

    ip_version=$(whiptail --menu "Select IP version:" 10 60 2 \
        4 "IPv4" \
        6 "IPv6" --nocancel 3>&1 1>&2 2>&3)

     Loop to validate IP address input
    valid_ip=1
    while [ $valid_ip -ne 0 ]; do
        if [ "$ip_version" == "4" ]; then
            exportip=$(input_dialog "Enter the SIEM/OPLC IPv4 address (This is the IP address for SIEM/OPLC):" "")
        else
            exportip=$(input_dialog "Enter the SIEM/OPLC IPv6 address (This is the IP address for SIEM/OPLC):" "")
        fi
        validate_ip "$exportip"
        valid_ip=$?
        if [ $valid_ip -ne 0 ]; then
            whiptail --msgbox "Invalid IP address format. Please try again." 15 40
        fi
    done

    #exportport=$(input_dialog "Enter the port for SIEM/OPLC (Default is 514):" "514")

 #   dnsmonitor=$(boolean_dialog "Enable DNS monitoring (true/false)\nThis is used for monitoring DNS queries. Default is false." "false")
  #  hostbandwidthmonitor=$(boolean_dialog "Enable Host Bandwidth Monitoring (true/false)\nThis is used for monitoring bandwidth usage. Default is false." "false")
   # netflowmonitor=$(boolean_dialog "Enable Netflow monitoring (true/false)\nThis is used for monitoring network traffic. Default is false." "false")
  #  procmonitor=$(boolean_dialog "Enable Proc monitoring (true/false)\nThis is used for monitoring process activities. Default is true." "true")
   # assetmonitor=$(boolean_dialog "Enable Asset monitoring (true/false)\nThis is used for monitoring asset information. Default is false." "false")
   # pkgmonitor=$(boolean_dialog "Enable Pkg monitoring (true/false)\nThis is used for monitoring package installations. Default is false." "false")
   # processmonitor=$(boolean_dialog "Enable Process monitoring (true/false)\nThis is used for monitoring running processes. Default is true." "true")
   # portmonitor=$(boolean_dialog "Enable Port monitoring (true/false)\nThis is used for monitoring open ports. Default is false." "false")
   # platformmonitor=$(boolean_dialog "Enable Platform monitoring (true/false)\nThis is used for monitoring platform-specific information. Default is false." "false")
   # fimmonitor=$(boolean_dialog "Enable FIM monitoring (true/false)\nThis is used for monitoring file integrity. Default is false." "false")

    # Write the entered values to a temporary file
    cat > agent.conf.tmp <<EOF
hostname = $hostname
export.ip = $exportip
export.port = 514
dns.monitor = false
host.bandwidth.monitor = false
netflow.monitor = false
proc.monitor = true
asset.monitor = false
pkg.monitor =  true
process.monitor = true
port.monitor = false
platform.monitor =  false
fim.monitor = false
log.monitor = true
log.files = file1,file2
log.files.file1.filepath = /var/log/syslog
log.files.file1.poll_interval = 10
log.files.file2.filepath = /var/log/*.log
log.files.file2.poll_interval = 10
EOF

    # Display the content of agent.conf.tmp for user review
#    whiptail --textbox agent.conf.tmp 20 80 --nocancel

    # Ask user to confirm the configuration
    if whiptail --yesno "Do you want to save this configuration?" 10 60 --nocancel; then
        continue="N"  # User confirmed, exit the loop
    else
        continue="Y"  # User wants to make changes, continue loop
    fi
done

# Move the confirmed configuration file to /etc/siem/agent/agent.conf
sudo mv agent.conf.tmp /etc/siem/agent/agent.conf
#sudo hostnamectl set-hostname $hostname
# Notify user that configuration has been saved
whiptail --msgbox "Configuration saved to /etc/siem/agent/agent.conf" 10 40 --nocancel

# Reload systemd daemon and enable/start services
sudo systemctl daemon-reload
#sudo systemctl enable activity-logger.service
sudo systemctl enable siem-agent.service
#sudo systemctl enable siem-agent.target 
sudo systemctl start siem-agent.service

# Checking whether user want web activity monitor or not.
#if whiptail --title "Continue?" --yesno "Do you want to enable web activity logger ?? (Extension required)" 10 60; then
    # If user clicks "Yes"
 #   echo ""
#else
    # If user clicks "No"
sudo systemctl stop  activity-logger.service
sudo systemctl disable activity-logger.service
#fi


# End of script
clear
# Locate the file and store the path in app_path
#app_path=$(find / -name "siem-linux-agent-ui-v1.tar.gz" -type f 2>/dev/null)

# Check if the file was found
#if [ -n "$app_path" ]; then
    # Remove the file
#    sudo rm -rf "$app_path"
#else
#    echo ""
#fi
#sudo rm -rf ./*
sudo systemctl status siem-agent.service
